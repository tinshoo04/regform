let nombre = document.getElementById('nombre')
let apellido = document.getElementById('apellido')
let email = document.getElementById('email')
let contraseña1 = document.getElementById('password1')
let contraseña2 = document.getElementById('password2')
let inputs = document.getElementsByClassName('form-control')
let terminos = document.getElementById('terminosLetra')
let letrasinvalido = document.getElementsByClassName("invalid-sm control")




document.getElementById('form').addEventListener('input', function(e){


document.getElementById('regBtn').addEventListener('click', e => { 
    e.preventDefault

    for (let input of inputs){
        if (input.checkValidity() === false) {
            input.setAttribute('style', 'border: 5px solid red')
            for (let aviso of letrasinvalido) {
                aviso.setAttribute('style', 'visibility: visible')
             }
             if(input.value.length > 0 || input.checkValidity()) {
                for (let aviso of letrasinvalido) {
                    aviso.setAttribute('style', 'visibility: hidden')
                 }
             }
        }
        
        

        }

        if(document.getElementById('terminos').checkValidity() == false) {
            terminos.setAttribute('style', 'color: red')
            document.getElementById('terms-service').innerHTML = "Acepta los terminos hijueputa"
            document.getElementById('label-terminos').setAttribute('style', 'color:red')
          } else {
            terminos.setAttribute('style', '')
            document.getElementById('terms-service').innerHTML = ""
            document.getElementById('label-terminos').setAttribute('style', '')
          }

})


if(contraseña1.checkValidity() !== false && contraseña2.checkValidity() !== false) {
    if(contraseña1.value.length <= 6 ) {
        contraseña1.setAttribute('style', 'border: 5px solid red')
    } 
    if (contraseña2.value !== contraseña1.value) {
        contraseña2.setAttribute('style', 'border: 5px solid red')
        contraseña1.setAttribute('style', 'border: 5px solid red')
    } else {
        contraseña2.setAttribute('style', '')
        contraseña1.setAttribute('style', '')
    }


    }




})
